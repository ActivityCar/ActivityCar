/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webcam;


import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import static java.lang.Thread.sleep;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
//import org.opencv.highgui.VideoCapture;
import org.opencv.imgproc.Imgproc;
import org.opencv.videoio.VideoCapture;

public class Webcam {

    static int SENSITIVITY_VALUE = 20;
    static int BLUR_SIZE = 10;
    static int WIDTH = 640;
    static int HEIGHT = 480;
    static JFrame frame=new JFrame();
    static JLabel lbl=new JLabel();
    static int conta=1;
   
    static LocalDateTime Time1; // = LocalDateTime.now();
    static LocalDateTime Time2; // = LocalDateTime.now();
    
    public static void main(String[] args) throws InterruptedException, IOException
    {
            System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
            Time1 = LocalDateTime.now();
            readFromCamera();
    }

    static void readFromCamera() throws InterruptedException, IOException
    {
        while (true)
        {
            VideoCapture camera = new VideoCapture(0);
            if (!camera.isOpened())
                    System.out.println("Cannot open file");

            else
            {
                Mat previousFrame = new Mat();
                Mat currentFrame = new Mat();
                Mat grayImage1 = new Mat();
                Mat grayImage2 = new Mat();
                Mat differenceImage = new Mat();
                Mat thresholdImage = new Mat();
                boolean frameSuccess;

                // THE INFINITE LOOP
                camera.read(previousFrame);

                Imgproc.resize(previousFrame, previousFrame, new Size(WIDTH,HEIGHT));
                Imgproc.cvtColor(previousFrame, grayImage1,
                                Imgproc.COLOR_BGR2GRAY);

                while (true)
                {
                    //sleep(150);
                     
                     frameSuccess = camera.read(currentFrame);
                     if (frameSuccess == true)
                     {
                             Imgproc.resize(currentFrame, currentFrame, new Size(WIDTH,HEIGHT));
                             Imgproc.cvtColor(currentFrame, grayImage2,
                                             Imgproc.COLOR_BGR2GRAY);

                     }else
                        break;
                        
                     // DIFFERENCE
                     Core.absdiff(grayImage1, grayImage2, differenceImage);
                    // displayImage(grayImage2);
                     Imgproc.threshold(differenceImage, thresholdImage,
                                     SENSITIVITY_VALUE, 255, Imgproc.THRESH_BINARY);
                     Imgproc.blur(thresholdImage, thresholdImage, new Size(
                                     BLUR_SIZE, BLUR_SIZE));
                     Imgproc.threshold(thresholdImage, thresholdImage,
                                     SENSITIVITY_VALUE, 255, Imgproc.THRESH_BINARY);

                     Mat hsv = currentFrame.clone();
                     
                     
                     Imgproc.cvtColor(currentFrame, hsv, Imgproc.COLOR_RGB2HSV);                        
                     //Core.inRange(currentFrame, new Scalar(0,0,230), new Scalar(0,0,255), hsv); //img
                     //searchForMovement(thresholdImage, currentFrame);
                     cercaColori(currentFrame,0);
                     grayImage2.copyTo(grayImage1);
                }
                camera.release();
            }
        }
    }
    static void searchForMovement(Mat thresholdImage, Mat frame1) throws IOException
    {
        List<MatOfPoint> contours = new ArrayList<MatOfPoint>();
        Mat hierarchy = new Mat();
        Imgproc.findContours(thresholdImage, contours, hierarchy,
                Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE);
      //  displayImage(hierarchy);
        
        Rect rect = new Rect(0, 0, 0, 0);
        for (int i = 0; i < contours.size(); i++)
        {
                rect = Imgproc.boundingRect(contours.get(i));
                if(checkRect(rect) && conta<2000)
                {   
                    Imgproc.rectangle(frame1, rect.tl(), rect.br(), new Scalar(255,255,255));
                    Mat subImg = frame1.submat(rect);
                    salvaImmagine(subImg);                    
                }
        }
        
        displayImage(frame1);
    }
    //NON FUNZIONA! DA SISTEMARE
    public static void cercaColori(Mat currentFrame,int colore) throws IOException
    {
       //colore:
        //0 --> blu
        //1 --> rosso
        //2 --> verde, ma non so come si fa...
        Mat hsv = currentFrame.clone();
        
        Mat threshold_lower = new Mat();
        Mat threshold_upper = new Mat();
        Imgproc.cvtColor(currentFrame, hsv, Imgproc.COLOR_RGB2HSV);   
        
        if(colore==0)
        {
            Core.inRange(hsv, new Scalar(0,135,135), new Scalar(20,255,255), threshold_lower); //img
            Core.inRange(hsv, new Scalar(160,135,135), new Scalar(180,255,255), threshold_upper); //img
        
            Core.add(threshold_lower,threshold_upper,hsv);
            threshold_lower.release();
            threshold_upper.release();;
        }
        if(colore==1)
            Core.inRange(hsv, new Scalar(100,135,135),new Scalar(130,255,255), hsv);
        
        displayImage(hsv);
    }
    public static boolean checkRect(Rect rect)
    {
        boolean ok = true;
        if(!(rect.area()>2000 && rect.area()<1000000)) ok=false;                  
        if(!(rect.height>0.75*rect.width && rect.height < 1.25*rect.width)) ok=false;
        return ok;
    }
    public static void salvaImmagine(Mat frame) throws IOException
    {
        Image img2 = Mat2BufferedImage(frame);
        String foto = "immagini\\immagine_"+(conta)+".png";
        conta++;
        ImageIO.write((RenderedImage) img2, "PNG", new File(foto));
    }
    public static void displayImage(Mat img) throws IOException
    {            
        //Dopo aver convertito un oggetto Mat, si usa questo metodo per visualizzarlo
        BufferedImage img2 = Mat2BufferedImage(img);
        
        BufferedImage m;
       
        ImageIcon icon=new ImageIcon(img2);
       // frame=new JFrame();
        frame.setLayout(new FlowLayout());   

        frame.setSize(img2.getWidth(null)+50, img2.getHeight(null)+50);     

        lbl.setIcon(icon);
        frame.add(lbl);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    } 
    public static BufferedImage Mat2BufferedImage(Mat m){ 

        //Questo metodo prende un oggetto Mat (della libreria openCV) e lo converte in
        //un oggetto BufferedImage, della libreria standard Java. Così si potrà
        //sfruttare i normali metodi della libreria java per visualizzare l'immagine su cui si 
        //ha lavorato

        int type = BufferedImage.TYPE_BYTE_GRAY;
        if ( m.channels() > 1 ) {
            type = BufferedImage.TYPE_3BYTE_BGR;
        }
        int bufferSize = m.channels()*m.cols()*m.rows();
        byte [] b = new byte[bufferSize];
        m.get(0,0,b); // get all the pixels
        BufferedImage image = new BufferedImage(m.cols(),m.rows(), type);
        final byte[] targetPixels = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
        System.arraycopy(b, 0, targetPixels, 0, b.length);  
        return image;
    }
    
}
